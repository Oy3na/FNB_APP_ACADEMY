#Controlle Statements
# if, elif, else

#num = 0

#if num > 0:
    #print("The number is positive.")
#elif num == 0:
    #print("The number is zero.")
#else:
    #print("The number is negative.")
    

num1 = int(input("Enter first number: "))
num2 = int(input("Enter second number: "))

if num1 > num2:
    print(f"{num1} is greater than {num2}.") # f-string for formatted output
elif num1 < num2:
    print(f"{num1} is less than {num2}.") # f-string for formatted output
else:
    print(f"{num1} is equal to {num2}.")