#Numeric Data Type
# An integer is a whole number, positive or negative, without decimals, of unlimited length.
# A float is a number, positive or negative, containing one or more decimals.

num = 5  # Define an integer
print(num)  # Print the integer
print(type(num))  # Print the type of the variable num

num2 = 5.5  # Define a float
print(num2)  # Print the float
print(type(num2))  # Print the type of the variable num2