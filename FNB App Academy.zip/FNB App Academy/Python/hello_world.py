print("Hello, World!") # This is a simple Python script that prints "Hello, World!" to the console.

