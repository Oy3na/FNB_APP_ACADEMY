# Strings 

#message = "Hello, World!"  # Define the message to be printed
#message = """Bob's World!
#is cool"""  # Define a multi-line message
#print(message)  # Print the message to the console

# Advanced concepts

message = "Hello, World!"  # Define the message to be printed


print(message[0])  # Print the first character of the message
print(message[1:5])  # Print characters from index 1 to 4
print(message[-1])  # Print the last character of the message

#Length method returns the number of characters in the string
print(len(message))  # Print the length of the message

#Strip method removes leading and trailing whitespace
print(message.strip())  # Print the message with leading and trailing whitespace removed

#Lowercase method converts the string to lowercase
print(message.lower())  # Print the message in lowercase

#Split method splits the string into a list of words based on the comma
print(message.split(","))  # Print the message split into a list of words

#Uppercase method converts the string to uppercase
print(message.upper())  # Print the message in uppercase

#Replace method replaces a substring with another substring
print(message.replace("World", "Universe"))  # Print the message with "World" replaced by "Universe"