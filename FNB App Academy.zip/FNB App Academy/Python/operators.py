#Operators

# Addition (+)
# Subtraction (-)
# Multiplication (*)
# Division (/)
# Modulus (%)
# Exponentiation (**)
# Floor Division (//)

x = 10
y = 3

print(x + y)  # Addition
print(x - y)  # Subtraction
print(x * y)  # Multiplication
print(x / y)  # Division
print(x % y)  # Modulus
print(x ** y)  # Exponentiation

#Argumented assignment operators
# +=, -=, *=, /=, %=, **=, //=

x -= 4 # Equivalent to x = x + 4
print(x)  # Output: 14

#Operators with strings
# Concatenation (+)

str1 = "Hello"
str2 = "World"
str3 = "This is Purpiie's World"
print(str1 + " " + str2 + " " + str3)  # Concatenation
print(str3 * 3)  # Repetition