#Loops

# For loop
# used to iterate over a sequence (like a list, tuple, or string) or other iterable objects

fruits = ["apple", "banana", "cherry"]
for fruit in fruits:
    print(fruit)  # Print each fruit in the list