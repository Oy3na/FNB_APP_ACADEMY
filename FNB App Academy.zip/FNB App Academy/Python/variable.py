#Variables
# A variable is a container for storing data values. In Python, variables do not need to be declared with a specific type, and they can change type dynamically.

#Rules in declaration of variables
# 1. Variable names must start with a letter or an underscore (_).
# 2. Variable names can only contain letters, numbers, and underscores.
# 3. Variable names are case-sensitive (e.g., myVar and myvar are different variables).
# 4. Variable names cannot be a reserved keyword in Python (e.g., if, else, while, etc.).

